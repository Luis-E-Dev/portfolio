# SAP CSRF Middleware

Middleware service that handles CSRF token validation with SAP API Management for Salesforce integration.

## Problem Solved

Salesforce cannot capture HTTP cookies from API responses due to platform security restrictions. SAP API Management requires session cookies + CSRF tokens for validation. This middleware:

1. Receives stateless requests from Salesforce
2. Fetches CSRF token + session cookies from SAP
3. Creates quotation in SAP with proper authentication
4. Returns SAP response to Salesforce

## Quick Start

### 1. Install Dependencies

```bash
cd sap-middleware
npm install
```

### 2. Configure Environment

```bash
cp .env.example .env
```

Edit `.env` and set a strong `MIDDLEWARE_API_KEY`:

```
MIDDLEWARE_API_KEY=DeaceroSF2SAP_SecureKey_2024
```

### 3. Run Locally

```bash
npm start
```

Test health check:
```bash
curl http://localhost:3000/health
```

## Deploy to Heroku

### 1. Install Heroku CLI

```bash
brew tap heroku/brew && brew install heroku
```

### 2. Login and Create App

```bash
heroku login
heroku create deacero-sap-middleware
```

### 3. Set Environment Variables

```bash
heroku config:set SAP_BASE_URL=https://intds4.test.apimanagement.us10.hana.ondemand.com
heroku config:set SAP_API_PATH=/API_THIRDPARTY_SRV/API_SALES_QUOTATION_SRV/A_SalesQuotation
heroku config:set SAP_CLIENT=250
heroku config:set SAP_USERNAME=QS4_API_CM01
heroku config:set SAP_PASSWORD=0n3De4cero2024!
heroku config:set SAP_API_KEY=QJbu9VB4HHxGAwyyROVDXDkGFyIf6wAv
heroku config:set MIDDLEWARE_API_KEY=DeaceroSF2SAP_SecureKey_2024
```

### 4. Deploy

```bash
git init
git add .
git commit -m "Initial SAP middleware deployment"
heroku git:remote -a deacero-sap-middleware
git push heroku main
```

### 5. Verify Deployment

```bash
heroku open
# Should open: https://deacero-sap-middleware.herokuapp.com

curl https://deacero-sap-middleware.herokuapp.com/health
```

## Salesforce Configuration

After deployment, your middleware URL will be:
`https://deacero-sap-middleware.herokuapp.com`

### Update Salesforce:

1. **Remote Site Setting:** Add middleware URL
2. **Named Credential:** Create `SAP_Middleware` with x-api-key
3. **Update Apex:** Change endpoint to `callout:SAP_Middleware/api/sap/quotation`

## API Endpoints

### GET /health
Health check endpoint

**Response:**
```json
{
  "status": "healthy",
  "timestamp": "2025-11-13T21:00:00.000Z",
  "service": "SAP CSRF Middleware"
}
```

### POST /api/sap/quotation
Create quotation in SAP

**Headers:**
- `Content-Type: application/json`
- `x-api-key: <MIDDLEWARE_API_KEY>`

**Body:** SAP quotation payload (same as Postman)

**Response:** SAP API response

## Monitoring

```bash
# View logs
heroku logs --tail -a deacero-sap-middleware

# Check status
heroku ps -a deacero-sap-middleware
```

## Security

✅ API Key authentication required  
✅ HTTPS enforced in production  
✅ Credentials in environment variables  
✅ CORS enabled for Salesforce

## Troubleshooting

**401 Unauthorized:** Check x-api-key header matches MIDDLEWARE_API_KEY

**500 Error:** Check Heroku logs for SAP connection issues

**CSRF Failed:** Verify SAP credentials and endpoint configuration

## Support

**Middleware Issues:** Check Heroku logs  
**SAP Issues:** Contact SAP team  
**Salesforce Issues:** Verify Named Credential configuration
