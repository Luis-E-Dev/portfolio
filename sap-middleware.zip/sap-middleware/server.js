require('dotenv').config();
const express = require('express');
const axios = require('axios');
const cors = require('cors');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json({ limit: '10mb' }));

// API Key authentication middleware
const authenticateApiKey = (req, res, next) => {
  const apiKey = req.headers['x-api-key'];
  
  if (!apiKey || apiKey !== process.env.MIDDLEWARE_API_KEY) {
    return res.status(401).json({ 
      error: 'Unauthorized',
      message: 'Invalid or missing API key' 
    });
  }
  
  next();
};

// Health check endpoint
app.get('/health', (req, res) => {
  res.json({ 
    status: 'healthy',
    timestamp: new Date().toISOString(),
    service: 'SAP CSRF Middleware'
  });
});

// Main proxy endpoint for SAP quotation creation
app.post('/api/sap/quotation', authenticateApiKey, async (req, res) => {
  try {
    console.log('Received quotation request from Salesforce');
    console.log('Payload:', JSON.stringify(req.body, null, 2));
    
    // Step 1: Fetch CSRF token and cookies from SAP
    const { csrfToken, cookies } = await fetchCSRFToken();
    console.log('CSRF token fetched successfully');
    console.log('Session cookies captured:', cookies ? 'Yes' : 'No');
    
    // Step 2: Send quotation to SAP with token and cookies
    const sapResponse = await createQuotation(req.body, csrfToken, cookies);
    console.log('Quotation created successfully in SAP');
    
    // Return SAP response to Salesforce
    res.status(sapResponse.status).json(sapResponse.data);
    
  } catch (error) {
    console.error('Error processing request:', error.message);
    
    if (error.response) {
      // SAP API error
      console.error('SAP Response Status:', error.response.status);
      console.error('SAP Response Data:', error.response.data);
      
      res.status(error.response.status).json({
        error: 'SAP API Error',
        message: error.response.data?.error?.message?.value || error.message,
        sapStatus: error.response.status,
        details: error.response.data
      });
    } else {
      // Network or other error
      res.status(500).json({
        error: 'Middleware Error',
        message: error.message
      });
    }
  }
});

// Fetch CSRF token from SAP
async function fetchCSRFToken() {
  const url = `${process.env.SAP_BASE_URL}${process.env.SAP_API_PATH}?sap-client=${process.env.SAP_CLIENT}`;
  
  const config = {
    method: 'GET',
    url: url,
    headers: {
      'x-csrf-token': 'Fetch',
      'Accept': 'application/json',
      'Accept-Encoding': 'identity',
      'Authorization': 'Basic ' + Buffer.from(`${process.env.SAP_USERNAME}:${process.env.SAP_PASSWORD}`).toString('base64'),
      'x-api-key': process.env.SAP_API_KEY,
      'sap-client': process.env.SAP_CLIENT
    },
    maxRedirects: 0,
    validateStatus: function (status) {
      return status >= 200 && status < 400;
    }
  };
  
  try {
    const response = await axios(config);
    
    // Extract CSRF token from response headers
    const csrfToken = response.headers['x-csrf-token'];
    
    // Extract cookies from Set-Cookie headers
    const setCookieHeaders = response.headers['set-cookie'];
    let cookies = '';
    
    if (setCookieHeaders && Array.isArray(setCookieHeaders)) {
      // Parse cookies and combine them
      cookies = setCookieHeaders
        .map(cookie => cookie.split(';')[0]) // Get only the cookie value, not attributes
        .join('; ');
    }
    
    if (!csrfToken) {
      throw new Error('No CSRF token received from SAP');
    }
    
    console.log('CSRF Token:', csrfToken);
    console.log('Cookies:', cookies || 'None');
    
    return { csrfToken, cookies };
    
  } catch (error) {
    console.error('Error fetching CSRF token:', error.message);
    throw new Error(`Failed to fetch CSRF token: ${error.message}`);
  }
}

// Create quotation in SAP
async function createQuotation(payload, csrfToken, cookies) {
  const url = `${process.env.SAP_BASE_URL}${process.env.SAP_API_PATH}?sap-client=${process.env.SAP_CLIENT}`;
  
  const config = {
    method: 'POST',
    url: url,
    headers: {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      'Accept-Encoding': 'identity',
      'Authorization': 'Basic ' + Buffer.from(`${process.env.SAP_USERNAME}:${process.env.SAP_PASSWORD}`).toString('base64'),
      'x-api-key': process.env.SAP_API_KEY,
      'x-csrf-token': csrfToken,
      'sap-client': process.env.SAP_CLIENT,
      'Cookie': cookies
    },
    data: payload,
    maxRedirects: 0,
    validateStatus: function (status) {
      return status >= 200 && status < 400;
    }
  };
  
  const response = await axios(config);
  return response;
}

// Start server
app.listen(PORT, () => {
  console.log(`\n🚀 SAP CSRF Middleware running on port ${PORT}`);
  console.log(`📍 Health check: http://localhost:${PORT}/health`);
  console.log(`📍 SAP Endpoint: ${process.env.SAP_BASE_URL}${process.env.SAP_API_PATH}`);
  console.log(`\n⚠️  Make sure to set MIDDLEWARE_API_KEY in .env file\n`);
});

// Graceful shutdown
process.on('SIGTERM', () => {
  console.log('SIGTERM received, shutting down gracefully');
  process.exit(0);
});
